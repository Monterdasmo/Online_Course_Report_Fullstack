# REPORT — Online Course Review (UA)

## 1. Загальна інформація про курс
**Назва курсу:** The Complete Full-Stack Web Development Bootcamp  
**Платформа:** Udemy  
**Автор курсу:** Dr. Angela Yu (The App Brewery, London)  
**Формат:** відеолекції + практичні завдання + проєкти

## 2. Мотивація вибору курсу
Курс було обрано для системного покриття ключових тем веб-розробки від базових технологій (HTML/CSS/JS) до створення повноцінних застосунків з використанням React, Node.js/Express та SQL/PostgreSQL. Очікуваний результат — закріплення фундаменту JS, покращення навичок вирішення алгоритмічних задач, а також розуміння full-stack підходу (API, автентифікація, взаємодія з БД, деплой).

## 3. Короткий огляд тем
- **Frontend:** HTML5, CSS3, Flexbox/Grid, Bootstrap, DOM, JavaScript (ES6+), React (components, props, state, hooks)
- **Інструменти:** bash, Git/GitHub, деплой (статичний/серверний)
- **Backend:** Node.js, Express, REST API, npm, middleware
- **Дані:** SQL та PostgreSQL, CRUD, зв’язки
- **Безпека:** базові підходи до автентифікації (cookies/sessions, OAuth)
- **Додатково:** вступ до Web3 (огляд + приклади)

## 4. Практичні завдання
Приклади реалізацій: `assets/solutions.js` (також відображаються на сторінці GitHub Pages).

## 5. Висновок
Курс практико-орієнтований і корисний для формування цілісної картини full-stack розробки.
