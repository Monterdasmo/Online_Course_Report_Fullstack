/**
 * UI wiring for the static GitHub Pages site.
 */

function setCode(id, code) {
  var el = document.getElementById(id);
  if (!el) return;
  el.textContent = code.trim();
}

setCode("code-bmi-round", bmiCalculatorRounded.toString());
setCode("code-leap", isLeap.toString());
setCode("code-fib", fibonacciGenerator.toString());
setCode("code-lunch", whosPaying.toString());

var teacherMessage = document.getElementById("teacherMessage");
if (teacherMessage) {
  teacherMessage.value =
`Добрий день!

Надсилаю посилання на публічний репозиторій зі звітом до додаткового завдання №2 (онлайн-курс).
У репозиторії знаходяться:
- REPORT.md — звіт/огляд курсу;
- демо-сторінка на GitHub Pages з прикладами виконаних JS-завдань.

Буду вдячний(а) за перевірку та зворотний зв’язок.

З повагою,
[ПІБ], група [Група]`;
}

var copyBtn = document.getElementById("copyBtn");
var copyStatus = document.getElementById("copyStatus");
if (copyBtn) {
  copyBtn.addEventListener("click", async function () {
    try {
      await navigator.clipboard.writeText(teacherMessage.value);
      if (copyStatus) copyStatus.textContent = "Скопійовано.";
      setTimeout(function () { if (copyStatus) copyStatus.textContent = ""; }, 1500);
    } catch (e) {
      if (copyStatus) copyStatus.textContent = "Не вдалось скопіювати (дозвольте доступ до буфера обміну).";
    }
  });
}

var runBtn = document.getElementById("runBtn");
var output = document.getElementById("output");
if (runBtn && output) {
  runBtn.addEventListener("click", function () {
    var lines = [];
    lines.push("=== Demo run ===");
    lines.push("BMI rounded (65, 1.8): " + bmiCalculatorRounded(65, 1.8));
    lines.push(bmiCalculatorAdvanced(65, 1.8));
    lines.push("Leap year 2400: " + isLeap(2400));
    lines.push("Leap year 1989: " + isLeap(1989));
    lines.push(whosPaying(["Angela", "Ben", "Jenny", "Michael", "Chloe"]));
    lines.push("Fibonacci n=7: [" + fibonacciGenerator(7).join(", ") + "]");
    lines.push(lifeInWeeksMessage(56));
    output.textContent = lines.join("\n");
  });
}
